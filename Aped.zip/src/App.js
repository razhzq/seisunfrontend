import logo from './logo.svg';
import HeaderNav from './components/HeaderNav';
import TradeView from './views/TradeView';
import AssetsView from './views/AssetsView';
import './App.css';
import "@fontsource/barlow";
import "@fontsource/barlow/400.css";
import "@fontsource/barlow/400-italic.css";
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";
import { useEffect, useState } from 'react';

function App() {
  // const [ scrollPosition, setScrollPosition ] = useState(0);
  // const handleScroll = () => {
  //   setScrollPosition(window.scrollY)
  //   const scrollPosition = window.scrollY;
  //   console.log(scrollPosition)
  // };

  // useEffect(() => {
  //   handleScroll();
  //   window.addEventListener("scroll", handleScroll);
  //   return () => {
  //     window.removeEventListener("scroll", handleScroll);
  //   };
  // }, [])

  return (
    
    <div className="App">
      <HeaderNav></HeaderNav>
      <TradeView></TradeView>
      {/* <div style={{transform: `translate(0px, -${scrollPosition}px)`}} className="bg-black"> */}
        <AssetsView ></AssetsView>
      {/* </div> */}
    </div>
  );
}

export default App;
